<?php
    //Include constants.php for SITEURL
    include('../config/constants.php');

    //1. Destroy the session
    session_destroy(); //Usset $_SEESION


    //2. Redirect to Login Page
    header('location'.SITEURL.'admin/login.php');


?>