<html>
<head>
    
    <title> Food Order Website - Home Page</title>
    <link rel = "stylesheet" href = "../css/admin.css" >

</head>

<body>
    <!-- Menu Section Starts -->
    <div class = "menu text-center" >
    <div class = "wrapper">
            <ul>
                <li><a href = "index.php"> Home</a></li>
                <li><a href = "manage-admin.php"> Admin</a></li>
                <li><a href = "manage-category.php"> Category</a></li>
                <li><a href =  "manage-food.php"> Food</a></li>
                <li><a href = "manage-order.php"> Order</a></li>
            </ul>
    </div>



    </div>
    <!-- Menu Section Ends -->


    <!-- Menu Content Section Starts -->
    <div class ="main-content">

        <div class = "wrapper">
            <strong>DASHBOARD</strong>
            <br><br>

            <?php
            if(isset($_SESSION['login'])){
                echo $_SESSION['login'];
                unset ($_SESSION['login']);
            }
            ?>
            <br><br>


            <div class="col-4 text-center">

                <?php
                    include('../config/constants.php');

                    //SQL Query
                    $sql = "SELECT * FROM tbl_category";
                    //Execute Query
                    $res = mysqli_query($conn, $sql);
                    //Count Rows
                    $count = mysqli_num_rows($res);
                ?>

                <h1><?php echo $count; ?></h1>
                <br/>
                Categories
            </div>

            <div class="col-4 text-center">

                <?php
                    //SQL Query
                    $sql2 = "SELECT * FROM tbl_category";
                    //Execute Query
                    $res2 = mysqli_query($conn, $sql2);
                    //Count Rows
                    $count2 = mysqli_num_rows($res2);
                ?>

                <h1><?php echo $count2; ?></h1>
                <br/>
                Foods
            </div>
            
            <div class="col-4 text-center">

                <?php
                    //SQL Query
                    $sql3 = "SELECT * FROM tbl_category";
                    //Execute Query
                    $res3 = mysqli_query($conn, $sql3);
                    //Count Rows
                    $count3 = mysqli_num_rows($res3);
                ?>

                <h1><?php echo $count3; ?></h1>
                <br/>
                Total Orders
            </div>

            <div class="col-4 text-center">
                <?php
                    //Create SQL Query to Get Total Revenue Generated
                    //Aggregate Function in SQL
                    $sql4 = "SELECT SUM(total) AS Total FROM tbl_order WHERE status='Delivered'";

                    //Execute Query
                    $res4 = mysqli_query($conn, $sql4);

                    //Count Rows
                    $row4 = mysqli_fetch_assoc($res4);

                    //Get the Total Revenue
                    $total_revenue = $row4['Total'];
                ?>

                <h1>$<?php echo $total_revenue; ?></h1>
                <br/>
                Revenue Generated
            </div>


            <div class = "clearfix" ></div>


         </div>

    </div>
    <!-- Menu Content Section Ends  -->




    <!-- Footer Section Starts -->
    <div class ="footer">

    <div class = "wrapper">
           <p class = "text-center"> 2022 All rights reserved by, Restaurant Name. Developed by Namo and Dragon ---<a href= "#">Namo</a>  </p>
    </div>

    </div>
    <!-- Footer Section Ends -->

</body>


</html>